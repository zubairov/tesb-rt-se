cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: talenddemosjava.osgitif_0_1.OSGiTIF --context=Default $* 